import graphics.EnglishStudyMain;

import java.awt.event.MouseAdapter;

public class EnglishStudy extends MouseAdapter {
	public static void main(String[] args){
		new EnglishStudyMain();
	}
}
